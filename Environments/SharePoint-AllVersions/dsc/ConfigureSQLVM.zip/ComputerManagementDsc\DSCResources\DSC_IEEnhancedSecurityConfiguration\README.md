# Description

This resource allows you to configure the IE Enhanced Security Configuration
for administrator or user roles.
